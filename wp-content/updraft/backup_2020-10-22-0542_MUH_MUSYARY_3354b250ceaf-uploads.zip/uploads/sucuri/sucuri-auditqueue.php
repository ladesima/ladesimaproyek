<?php
// datastore=auditqueue;
// created_on=1603342125;
// updated_on=1603342289;
exit(0);
?>
1603342125_8436:"Warning: ladesima1221, 127.0.0.1; Plugin activated: Sucuri Security - Auditing, Malware Scanner and Hardening (v1.8.24; sucuri-scanner\/sucuri.php)"
1603345285_2075:"Warning: ladesima1221, 127.0.0.1; Plugin activated: UpdraftPlus - Backup\/Restore (v1.16.31; updraftplus\/updraftplus.php)"
